# Comandos básicos

Para instalar dependencias

```
npm install
```

Para executar o programa

```
npx expo start
```

![imagem](https://i.imgur.com/q7zvlbL.png)
