# Projeto Prático B2

## Identificação

- Nome: Lucas Carrijo Ferrari
- Turma: CC3M
- Matricula: 202203167

## Informações

- Favor utilizar as dimensões de um Iphone 12 Pro

![imagem](https://i.imgur.com/WRwRIhy.png)

- Para acessar a página de dashboard, clique no botão de Login.

![imagem](https://i.imgur.com/dvF21jl.gif)

## Comandos básicos

Para instalar dependencias

```
npm install
```

Para executar o programa (lembre-se de selecionar a opção web com o botão W)

```
npx expo start
```
