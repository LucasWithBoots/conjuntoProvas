# NowRecycle ♻️

Esta foi uma pequena página desenvolvido pelo nosso grupo para a disciplina de Desenvolvimento Web. O site tem como intuito fornecer uma coleta de materiais que iriam ao descarte comum para serem reciclados.

## Integrantes 🔎

- Lucas Carrijo Ferrari
- Rayssa Kellen Gomes Martins
- Marco Antônio da Silva Alves

## Links úteis 🔗

- A página funcionando pelo Github pode ser visualizada clicando [aqui](https://luwucaz.github.io/CONWEB-Projeto_Integrado/)
- A página pelo servidor da UVV pode ser vista [aqui](https://disciplinas.uvv.br/cc1m/g8/)
- O protótipo feito no Figma pode ser encontrado por [este link](https://bit.ly/3GoMou9)

### Credits

*I would like to shoutout these creators for the images that were used at this project:*

- [Kay Ingulli](https://unsplash.com/@kingulli?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText)
- [Giovana Gomes](https://unsplash.com/es/@gimazzarello?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText)
- [Christin Hume](https://unsplash.com/@christinhumephoto?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText)
- [Elly Filho](https://unsplash.com/@ellyfilho?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText)
