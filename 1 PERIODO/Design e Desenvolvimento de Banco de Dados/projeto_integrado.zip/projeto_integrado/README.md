# 💠 Projeto Integrado

## Integrantes 🔎

- Lucas Carrijo Ferrari
- Rayssa Kellen Gomes Martins
- Marco Antônio da Silva Alves
- Lorhana Roncetti

## Sobre 

Este sub-diretório contêm:

- **projeto_conceitual.brM3:** Projeto conceitual no BrModelo
- **projeto_logico:** Projeo lógico no SQL Power Architect
- **script_postgres.sql:** Script corretamente implementado no servidor de banco de dados PostgreSQL no site [disciplinas.uvv.br](https://disciplinas.uvv.br/)
