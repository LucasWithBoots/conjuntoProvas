INSERT INTO hr.regioes (id_regiao,nome) VALUES
	 (1,'Europe'),
	 (2,'Americas'),
	 (3,'Asia'),
	 (4,'Middle East and Africa');
