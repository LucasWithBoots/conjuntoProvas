## Sobre 🔎

Primeiro trabalho feito e publicado aqui no GitHub. Se trata de um banco de dados voltado à visualização de um sistema de Recursos Humanos. O software cliente utilizado para manipular os bancos de dados foi o **DBeaver**.

Inclui os seguintes arquivos:
- **cc1m_202203167_hr.architect:** Diagrama do banco de dados comentado e estruturado
- **cc1m_202203167_mysql_hr.sql:** Toda a estrutura do banco de dados criado especificamente para o MySQL
- **cc1m_202203167_postgresql_hr.sql:** Toda a estrutura do banco de dados criado especificamente para o Postgres


<div align="center"><img src="https://i.imgur.com/HQVlwMK.jpeg" width="700px"></div>
