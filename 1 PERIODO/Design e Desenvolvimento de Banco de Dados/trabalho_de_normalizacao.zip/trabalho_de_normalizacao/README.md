# 🌵 Trabalho de Normalização

## Integrantes 🔎

- Lucas Carrijo Ferrari
- Rayssa Kellen Gomes Martins
- Marco Antônio da Silva Alves
- Lorhana Roncetti

## Sobre 

Este sub-diretório contêm:

- **projeto_logico:** Projeto lógico no SQL Power Architect
- **script_postgres.sql:** Script do projeto de jogo específico para o PostgreSQL
